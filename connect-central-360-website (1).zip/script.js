(() => {
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const btn = document.querySelector(".menu");
  const nav = document.getElementById("mobileNav");
  if (!btn || !nav) return;

  btn.addEventListener("click", () => {
    const isOpen = btn.getAttribute("aria-expanded") === "true";
    btn.setAttribute("aria-expanded", String(!isOpen));
    nav.hidden = isOpen;
  });

  // Close mobile nav on click
  nav.addEventListener("click", (e) => {
    const t = e.target;
    if (t && t.tagName === "A") {
      btn.setAttribute("aria-expanded", "false");
      nav.hidden = true;
    }
  });
})();
