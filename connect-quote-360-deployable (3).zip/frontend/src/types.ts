export type Plan = { id: number; plan_code: string; name: string; plan_type: string; carrier: string; };

export type Quote = {
  quote_number: string;
  market: string;
  employer_name: string;
  status: string;
  dsl_text: string;
};

export type PricingSummary = {
  quote_number: string;
  market: string;
  employer_name: string;
  plan_code: string;
  plan_name: string;
  tier_premiums: Array<{
    tier: "EE" | "ES" | "EC" | "FAM";
    premium: number;
    employer_contribution: number;
    employee_contribution: number;
  }>;
  totals: { premium_total: number; employer_total: number; employee_total: number; };
  assumptions: Record<string, string>;
};

export type ArtifactMeta = {
  id: number;
  kind: "pdf" | "834";
  filename: string;
  content_type: string;
  size_bytes: number;
  created_at: string;
};

export type PartnerRule = { id: number; partner: string; rule_key: string; rule_value: string; notes: string; };
export type PartnerRef = { id: number; partner: string; ref_code: string; scope: string; source_field: string; required: boolean; notes: string; };
export type PartnerPlanMap = { id: number; partner: string; internal_plan_code: string; partner_plan_code: string; line_of_business: string; product_code: string; active: boolean; notes: string; };
