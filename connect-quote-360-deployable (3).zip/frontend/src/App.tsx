import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { isAuthed } from "./auth";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { NewQuote } from "./pages/NewQuote";
import { QuoteDetail } from "./pages/QuoteDetail";
import { PartnerAdmin } from "./pages/PartnerAdmin";

function Guard({ children }: { children: React.ReactNode }) {
  return isAuthed() ? <>{children}</> : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Guard><Dashboard /></Guard>} />
        <Route path="/new" element={<Guard><NewQuote /></Guard>} />
        <Route path="/q/:quoteNumber" element={<Guard><QuoteDetail /></Guard>} />
        <Route path="/partners" element={<Guard><PartnerAdmin /></Guard>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
