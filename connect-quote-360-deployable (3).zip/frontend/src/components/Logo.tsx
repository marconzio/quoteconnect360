import React from "react";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-600 shadow-soft flex items-center justify-center">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 2l8 4v6c0 5-3.5 9.5-8 10-4.5-.5-8-5-8-10V6l8-4z" stroke="white" strokeWidth="1.6"/>
          <path d="M8.2 12.1l2.2 2.2 5.4-5.4" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      {!compact && (
        <div className="leading-tight">
          <div className="text-sm font-semibold tracking-wide text-slate-800">Connect Quote 360</div>
          <div className="text-xs text-slate-500">Quoting • Artifacts • 834 • Partner Profiles</div>
        </div>
      )}
    </div>
  );
}
