import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Logo } from "./Logo";
import { Button } from "./Button";
import { clearToken } from "../auth";

export function Shell({ children }: { children: React.ReactNode }) {
  const nav = useNavigate();
  return (
    <div className="min-h-screen">
      <div className="sticky top-0 z-40 bg-slate-50/85 backdrop-blur border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between">
          <Link to="/" className="no-underline"><Logo /></Link>
          <div className="flex items-center gap-2">
            <Link to="/new"><Button variant="ghost">New Quote</Button></Link>
            <Link to="/partners"><Button variant="ghost">Partner Config</Button></Link>
            <Button variant="ghost" onClick={() => { clearToken(); nav("/login"); }}>Sign out</Button>
          </div>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-5 py-6">{children}</div>
    </div>
  );
}
