export function setToken(token: string) { localStorage.setItem("c360_token", token); }
export function getToken(): string | null { return localStorage.getItem("c360_token"); }
export function clearToken() { localStorage.removeItem("c360_token"); }
export function isAuthed(): boolean { return !!getToken(); }
