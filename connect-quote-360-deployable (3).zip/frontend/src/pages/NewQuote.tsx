import React, { useEffect, useState } from "react";
import { api } from "../api";
import { Shell } from "../components/Shell";
import { Card, CardBody, CardHeader } from "../components/Card";
import { Input, TextArea } from "../components/Input";
import { Select } from "../components/Select";
import { Button } from "../components/Button";
import { Plan } from "../types";

export function NewQuote() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [market, setMarket] = useState("SMB");
  const [employer, setEmployer] = useState("");
  const [partner, setPartner] = useState<"TallTree" | "VaultTPA">("TallTree");
  const [planCode, setPlanCode] = useState("");
  const [dsl, setDsl] = useState(
`# Pricing DSL
base_rate_ee=450
base_rate_es=900
base_rate_ec=820
base_rate_fam=1200
employer_pct=0.75
`
  );
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await api<Plan[]>("/ui/plans");
        setPlans(res);
        if (res[0]) setPlanCode(res[0].plan_code);
      } catch (e: any) {
        setErr(e.message);
      }
    })();
  }, []);

  async function create() {
    setErr("");
    try {
      const res = await api<{ quote_number: string }>("/ui/quotes", {
        method: "POST",
        body: JSON.stringify({
          market,
          employer_name: employer,
          dsl_text: dsl,
          plan_code: planCode,
          partner
        })
      });
      window.location.href = `/q/${res.quote_number}`;
    } catch (e: any) {
      setErr(e.message);
    }
  }

  return (
    <Shell>
      <Card>
        <CardHeader title="New Quote" subtitle="Create a quote, run pricing, generate artifacts." />
        <CardBody>
          {err && <div className="text-sm text-red-600 mb-4">{err}</div>}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="space-y-3">
              <div>
                <div className="text-xs font-semibold text-slate-600 mb-1">Market</div>
                <Select value={market} onChange={(e) => setMarket(e.target.value)}>
                  <option value="SMB">SMB</option>
                  <option value="Mid">Mid</option>
                  <option value="Public">Public</option>
                </Select>
              </div>

              <div>
                <div className="text-xs font-semibold text-slate-600 mb-1">Employer Name</div>
                <Input value={employer} onChange={(e) => setEmployer(e.target.value)} placeholder="Acme City Schools" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="text-xs font-semibold text-slate-600 mb-1">Partner</div>
                  <Select value={partner} onChange={(e) => setPartner(e.target.value as any)}>
                    <option value="TallTree">Tall Tree</option>
                    <option value="VaultTPA">Vault TPA</option>
                  </Select>
                </div>

                <div>
                  <div className="text-xs font-semibold text-slate-600 mb-1">Plan</div>
                  <Select value={planCode} onChange={(e) => setPlanCode(e.target.value)}>
                    {plans.map((p) => (
                      <option key={p.plan_code} value={p.plan_code}>
                        {p.plan_code} — {p.name}
                      </option>
                    ))}
                  </Select>
                </div>
              </div>

              <Button onClick={create} className="w-full" disabled={!employer || !planCode}>Create Quote</Button>
              <div className="text-xs text-slate-500">Partner selection is stored on QuoteSelection.</div>
            </div>

            <div>
              <div className="text-xs font-semibold text-slate-600 mb-1">Pricing Rules DSL</div>
              <TextArea value={dsl} onChange={(e) => setDsl(e.target.value)} />
            </div>
          </div>
        </CardBody>
      </Card>
    </Shell>
  );
}
