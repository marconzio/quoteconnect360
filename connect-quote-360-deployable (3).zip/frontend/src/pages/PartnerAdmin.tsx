import React, { useEffect, useState } from "react";
import { api } from "../api";
import { Shell } from "../components/Shell";
import { Card, CardBody, CardHeader } from "../components/Card";
import { Select } from "../components/Select";
import { PartnerRule, PartnerRef, PartnerPlanMap } from "../types";

export function PartnerAdmin() {
  const [partner, setPartner] = useState<"TallTree" | "VaultTPA">("TallTree");
  const [rules, setRules] = useState<PartnerRule[]>([]);
  const [refs, setRefs] = useState<PartnerRef[]>([]);
  const [maps, setMaps] = useState<PartnerPlanMap[]>([]);
  const [err, setErr] = useState("");

  async function load() {
    setErr("");
    try {
      const [r, rf, m] = await Promise.all([
        api<PartnerRule[]>(`/ui/partners/${partner}/rules`),
        api<PartnerRef[]>(`/ui/partners/${partner}/refs`),
        api<PartnerPlanMap[]>(`/ui/partners/${partner}/plan-maps`)
      ]);
      setRules(r); setRefs(rf); setMaps(m);
    } catch (e: any) {
      setErr(e.message);
    }
  }

  useEffect(() => { load(); }, [partner]);

  return (
    <Shell>
      {err && <div className="text-sm text-red-600 mb-4">{err}</div>}
      <div className="flex items-center gap-3 mb-4">
        <div className="text-sm font-semibold text-slate-700">Partner:</div>
        <div className="w-52">
          <Select value={partner} onChange={(e) => setPartner(e.target.value as any)}>
            <option value="TallTree">Tall Tree</option>
            <option value="VaultTPA">Vault TPA</option>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        <Card>
          <CardHeader title="834 Rules" subtitle="Required segments, qualifiers, flags, DTP behavior." />
          <CardBody>
            <div className="space-y-2">
              {rules.map((x) => (
                <div key={x.id} className="rounded-xl border border-slate-100 p-3">
                  <div className="text-sm font-semibold">{x.rule_key}</div>
                  <div className="text-xs text-slate-600 mt-1">{x.rule_value}</div>
                  {x.notes && <div className="text-xs text-slate-400 mt-1">{x.notes}</div>}
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="REF Map" subtitle="REF qualifiers by scope (member/coverage/sponsor)." />
          <CardBody>
            <div className="space-y-2">
              {refs.map((x) => (
                <div key={x.id} className="rounded-xl border border-slate-100 p-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-semibold">REF*{x.ref_code}</div>
                    <div className={`text-xs font-semibold px-2 py-1 rounded-lg ${x.required ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-700"}`}>
                      {x.scope}
                    </div>
                  </div>
                  <div className="text-xs text-slate-600 mt-1">source_field: <span className="font-mono">{x.source_field}</span></div>
                  {x.notes && <div className="text-xs text-slate-400 mt-1">{x.notes}</div>}
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Plan / Product Mapping" subtitle="Internal → partner codes (HD loop, product IDs)." />
          <CardBody>
            <div className="space-y-2">
              {maps.map((x) => (
                <div key={x.id} className="rounded-xl border border-slate-100 p-3">
                  <div className="text-sm font-semibold">{x.internal_plan_code} → {x.partner_plan_code}</div>
                  <div className="text-xs text-slate-600 mt-1">LOB: {x.line_of_business} • product: {x.product_code || "—"}</div>
                  {x.notes && <div className="text-xs text-slate-400 mt-1">{x.notes}</div>}
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>
    </Shell>
  );
}
