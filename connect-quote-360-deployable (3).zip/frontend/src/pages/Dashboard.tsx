import React, { useEffect, useState } from "react";
import { api } from "../api";
import { Shell } from "../components/Shell";
import { Card, CardBody, CardHeader } from "../components/Card";
import { Link } from "react-router-dom";

type QuoteRow = { quote_number: string; employer_name: string; market: string; status: string; created_at?: string };

export function Dashboard() {
  const [quotes, setQuotes] = useState<QuoteRow[]>([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await api<QuoteRow[]>("/ui/quotes/recent");
        setQuotes(res);
      } catch (e: any) {
        setErr(e.message);
      }
    })();
  }, []);

  return (
    <Shell>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2">
          <CardHeader title="Recent Quotes" subtitle="Open a quote to run pricing and generate artifacts." />
          <CardBody>
            {err && <div className="text-sm text-red-600 mb-3">{err}</div>}
            <div className="space-y-2">
              {quotes.length === 0 && <div className="text-sm text-slate-500">No quotes yet. Create your first quote.</div>}
              {quotes.map((q) => (
                <Link key={q.quote_number} to={`/q/${q.quote_number}`} className="block">
                  <div className="rounded-xl border border-slate-100 hover:border-slate-200 bg-white px-4 py-3 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold">{q.employer_name}</div>
                      <div className="text-xs text-slate-500">{q.quote_number} • {q.market}</div>
                    </div>
                    <div className="text-xs font-semibold px-2 py-1 rounded-lg bg-slate-100 text-slate-700">{q.status}</div>
                  </div>
                </Link>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Connect Quote 360" subtitle="What you’re running." />
          <CardBody>
            <ul className="text-sm text-slate-600 space-y-2">
              <li>• Postgres-backed quote records</li>
              <li>• Pricing DSL → canonical summary</li>
              <li>• PDF + 834 artifact generation</li>
              <li>• Partner mapping tables (rules/REF/plan codes)</li>
            </ul>
          </CardBody>
        </Card>
      </div>
    </Shell>
  );
}
