import React, { useState } from "react";
import { api } from "../api";
import { setToken } from "../auth";
import { Logo } from "../components/Logo";
import { Card, CardBody, CardHeader } from "../components/Card";
import { Input } from "../components/Input";
import { Button } from "../components/Button";

export function Login() {
  const [email, setEmail] = useState("admin@connect360.local");
  const [password, setPassword] = useState("admin123");
  const [err, setErr] = useState("");

  async function onLogin() {
    setErr("");
    try {
      const res = await api<{ access_token: string; role: string }>("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password })
      });
      setToken(res.access_token);
      window.location.href = "/";
    } catch (e: any) {
      setErr(e.message);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-5">
      <div className="w-full max-w-md">
        <div className="mb-6 flex justify-center"><Logo /></div>
        <Card>
          <CardHeader title="Sign in" subtitle="Use your Connect Quote 360 credentials." />
          <CardBody>
            <div className="space-y-3">
              <div>
                <div className="text-xs font-semibold text-slate-600 mb-1">Email</div>
                <Input value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-600 mb-1">Password</div>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              {err && <div className="text-sm text-red-600">{err}</div>}
              <Button className="w-full" onClick={onLogin}>Sign in</Button>
              <div className="text-xs text-slate-500 pt-2">
                Sample users: admin@connect360.local / admin123 • uw@connect360.local / uw123 • broker@connect360.local / broker123
              </div>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
