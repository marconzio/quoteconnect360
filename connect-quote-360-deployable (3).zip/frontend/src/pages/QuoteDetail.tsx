import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api, download } from "../api";
import { Shell } from "../components/Shell";
import { Card, CardBody, CardHeader } from "../components/Card";
import { Button } from "../components/Button";
import { Quote, PricingSummary, ArtifactMeta } from "../types";

export function QuoteDetail() {
  const { quoteNumber } = useParams();
  const [quote, setQuote] = useState<Quote | null>(null);
  const [pricing, setPricing] = useState<PricingSummary | null>(null);
  const [artifacts, setArtifacts] = useState<ArtifactMeta[]>([]);
  const [planCode, setPlanCode] = useState("C360MED01");
  const [err, setErr] = useState("");

  async function refresh() {
    if (!quoteNumber) return;
    setErr("");
    try {
      const q = await api<Quote>(`/quotes/${quoteNumber}`);
      setQuote(q);
      const arts = await api<ArtifactMeta[]>(`/ui/quotes/${quoteNumber}/artifacts`);
      setArtifacts(arts);
    } catch (e: any) {
      setErr(e.message);
    }
  }

  useEffect(() => { refresh(); }, [quoteNumber]);

  async function runPricing() {
    if (!quoteNumber) return;
    setErr("");
    try {
      const ps = await api<PricingSummary>(`/quotes/${quoteNumber}/pricing?plan_code=${encodeURIComponent(planCode)}`, { method: "POST" });
      setPricing(ps);
    } catch (e: any) {
      setErr(e.message);
    }
  }

  async function makePdf() {
    if (!quoteNumber) return;
    setErr("");
    try {
      await api(`/artifacts/${quoteNumber}/pdf?plan_code=${encodeURIComponent(planCode)}`, { method: "POST" });
      await refresh();
    } catch (e: any) {
      setErr(e.message);
    }
  }

  async function make834() {
    if (!quoteNumber) return;
    setErr("");
    try {
      await api(`/artifacts/${quoteNumber}/834?plan_code=${encodeURIComponent(planCode)}`, { method: "POST" });
      await refresh();
    } catch (e: any) {
      setErr(e.message);
    }
  }

  return (
    <Shell>
      {err && <div className="text-sm text-red-600 mb-4">{err}</div>}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2">
          <CardHeader
            title={quote ? `${quote.employer_name}` : "Quote"}
            subtitle={quote ? `${quote.quote_number} • ${quote.market} • Status: ${quote.status}` : "Loading..."}
            right={
              <div className="flex gap-2">
                <Button variant="ghost" onClick={runPricing}>Run Pricing</Button>
                <Button variant="ghost" onClick={makePdf}>Generate PDF</Button>
                <Button onClick={make834}>Generate 834</Button>
              </div>
            }
          />
          <CardBody>
            {!pricing && (
              <div className="text-sm text-slate-500">
                Click <b>Run Pricing</b> to generate the canonical pricing summary.
              </div>
            )}

            {pricing && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl border border-slate-100 p-3">
                    <div className="text-xs text-slate-500">Premium Total</div>
                    <div className="text-lg font-semibold">${pricing.totals.premium_total.toFixed(2)}</div>
                  </div>
                  <div className="rounded-xl border border-slate-100 p-3">
                    <div className="text-xs text-slate-500">Employer Total</div>
                    <div className="text-lg font-semibold">${pricing.totals.employer_total.toFixed(2)}</div>
                  </div>
                </div>

                <div className="overflow-hidden rounded-xl border border-slate-100">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 text-slate-600">
                      <tr>
                        <th className="text-left p-3">Tier</th>
                        <th className="text-right p-3">Premium</th>
                        <th className="text-right p-3">Employer</th>
                        <th className="text-right p-3">Employee</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pricing.tier_premiums.map((t) => (
                        <tr key={t.tier} className="border-t border-slate-100">
                          <td className="p-3 font-semibold">{t.tier}</td>
                          <td className="p-3 text-right">${t.premium.toFixed(2)}</td>
                          <td className="p-3 text-right">${t.employer_contribution.toFixed(2)}</td>
                          <td className="p-3 text-right">${t.employee_contribution.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <details className="rounded-xl border border-slate-100 p-3">
                  <summary className="cursor-pointer text-sm font-semibold text-slate-700">Assumptions (DSL)</summary>
                  <pre className="text-xs mt-2 bg-slate-50 rounded-xl p-3 overflow-auto">
{JSON.stringify(pricing.assumptions, null, 2)}
                  </pre>
                </details>
              </div>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Artifacts" subtitle="PDF + 834 outputs. Download anytime." />
          <CardBody>
            <div className="space-y-2">
              {artifacts.length === 0 && <div className="text-sm text-slate-500">No artifacts generated yet.</div>}
              {artifacts.map((a) => (
                <div key={a.id} className="rounded-xl border border-slate-100 p-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold">{a.filename}</div>
                    <div className="text-xs text-slate-500">{a.kind.toUpperCase()} • {Math.round(a.size_bytes/1024)} KB</div>
                  </div>
                  <Button variant="ghost" onClick={() => download(`/artifacts/${a.id}`, a.filename)}>Download</Button>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>
    </Shell>
  );
}
