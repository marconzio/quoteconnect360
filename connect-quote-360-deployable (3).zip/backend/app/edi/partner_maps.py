from __future__ import annotations
from typing import Dict, List, Optional
from sqlalchemy.orm import Session
from app.db import models

def get_partner_rules(db: Session, partner: str) -> Dict[str, str]:
    rows = db.query(models.Partner834Rule).filter(models.Partner834Rule.partner == partner).all()
    return {r.rule_key: r.rule_value for r in rows}

def get_partner_ref_map(db: Session, partner: str) -> List[models.PartnerRefQualifier]:
    return (
        db.query(models.PartnerRefQualifier)
        .filter(models.PartnerRefQualifier.partner == partner)
        .order_by(models.PartnerRefQualifier.scope.asc(), models.PartnerRefQualifier.ref_code.asc())
        .all()
    )

def resolve_partner_plan_code(db: Session, partner: str, internal_plan_code: str, *, require_active: bool = True) -> models.PartnerPlanCodeMap:
    q = db.query(models.PartnerPlanCodeMap).filter(
        models.PartnerPlanCodeMap.partner == partner,
        models.PartnerPlanCodeMap.internal_plan_code == internal_plan_code,
    )
    if require_active:
        q = q.filter(models.PartnerPlanCodeMap.active == True)  # noqa: E712
    row: Optional[models.PartnerPlanCodeMap] = q.first()
    if not row:
        suffix = " (active required)" if require_active else ""
        raise ValueError(f"No partner plan code mapping for partner={partner} internal_plan_code={internal_plan_code}{suffix}")
    return row
