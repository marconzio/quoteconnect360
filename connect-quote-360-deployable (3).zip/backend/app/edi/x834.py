REL_TO_INS = {"EMP": "18", "SPO": "01", "CHD": "19"}

def generate_834(*, sender_id: str, receiver_id: str, group_id: str,
                 quote_number: str, employer_name: str,
                 plan_code: str, members: list[dict]) -> str:
    seg = []
    seg.append(f"ISA*00*          *00*          *ZZ*{sender_id:<15}*ZZ*{receiver_id:<15}*260204*0000*^*00501*{quote_number[-9:]:0>9}*0*T*:~")
    seg.append(f"GS*BE*{sender_id}*{receiver_id}*20260204*0000*{group_id}*X*005010X220A1~")
    seg.append(f"ST*834*{quote_number}*005010X220A1~")
    seg.append(f"BGN*00*{quote_number}*20260204*0000*4~")
    seg.append(f"N1*P5*{employer_name}~")

    seg.append(f"HD*030**HLT*{plan_code}**EMP~")

    for m in members:
        rel = m.get("relationship","EMP")
        ins_rel = REL_TO_INS.get(rel, "18")
        seg.append(f"INS*Y*{ins_rel}*030*XN*A*E**FT~")
        seg.append(f"REF*0F*{m.get('employee_id','')}~")
        seg.append(f"NM1*IL*1*{m.get('last_name','')}*{m.get('first_name','')}****34*{m.get('ssn_last4','')}~")
        seg.append(f"DMG*D8*{m.get('dob','')}~")

    seg.append("SE*999*0001~")
    seg.append(f"GE*1*{group_id}~")
    seg.append(f"IEA*1*{quote_number[-9:]:0>9}~")
    return "\n".join(seg)
