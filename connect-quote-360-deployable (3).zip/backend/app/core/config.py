from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str
    JWT_SECRET: str = "dev-change-me"
    JWT_ALG: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 480

    # SFTP watcher (optional)
    SFTP_HOST: str = ""
    SFTP_PORT: int = 22
    SFTP_USER: str = ""
    SFTP_PASSWORD: str = ""
    SFTP_REMOTE_DIR: str = "/inbound"

    # Artifact storage provider
    ARTIFACT_PROVIDER: str = "local"  # local|s3|azure
    S3_BUCKET: str = ""
    AWS_REGION: str = "us-west-2"
    AZURE_STORAGE_CONNECTION_STRING: str = ""
    AZURE_CONTAINER: str = ""

settings = Settings()
