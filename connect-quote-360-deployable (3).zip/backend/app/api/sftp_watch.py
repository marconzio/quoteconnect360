import time
from sqlalchemy.orm import Session
from app.core.config import settings

def poll_sftp_and_ingest(db: Session):
    # Optional / stub in this demo build
    if not settings.SFTP_HOST:
        return

def start_background_watcher(SessionLocal):
    while True:
        try:
            db = SessionLocal()
            poll_sftp_and_ingest(db)
        except Exception:
            pass
        finally:
            try:
                db.close()
            except Exception:
                pass
        time.sleep(15)
