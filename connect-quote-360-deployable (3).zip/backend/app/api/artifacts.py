from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db import models
from app.core.rbac import require_roles
from app.pricing.evaluator import evaluate_quote_pricing
from app.pdf.quote_pdf import build_quote_pdf
from app.edi.x834 import generate_834

router = APIRouter(prefix="/artifacts", tags=["artifacts"])

@router.post("/{quote_number}/pdf", dependencies=[Depends(require_roles("admin","underwriter","broker"))])
def create_pdf(quote_number: str, plan_code: str, db: Session = Depends(get_db)):
    quote = db.query(models.Quote).filter(models.Quote.quote_number == quote_number).first()
    plan = db.query(models.Plan).filter(models.Plan.plan_code == plan_code).first()
    if not quote or not plan:
        raise HTTPException(status_code=404, detail="Quote/Plan not found")

    summary = evaluate_quote_pricing(
        quote_number=quote.quote_number,
        market=quote.market,
        employer_name=quote.employer_name,
        plan_code=plan.plan_code,
        plan_name=plan.name,
        dsl_text=quote.dsl_text
    ).model_dump()

    pdf_bytes = build_quote_pdf(title=f"Quote {quote.quote_number}", summary=summary)
    art = models.Artifact(quote_id=quote.id, kind="pdf", filename=f"{quote.quote_number}.pdf", content=pdf_bytes)
    db.add(art); db.commit(); db.refresh(art)
    return {"artifact_id": art.id, "filename": art.filename}

@router.post("/{quote_number}/834", dependencies=[Depends(require_roles("admin","underwriter","broker"))])
def create_834(quote_number: str, plan_code: str, db: Session = Depends(get_db)):
    quote = db.query(models.Quote).filter(models.Quote.quote_number == quote_number).first()
    plan = db.query(models.Plan).filter(models.Plan.plan_code == plan_code).first()
    if not quote or not plan:
        raise HTTPException(status_code=404, detail="Quote/Plan not found")

    members = db.query(models.QuoteMember).filter(models.QuoteMember.quote_id == quote.id).all()
    text = generate_834(
        sender_id="CONNECT360",
        receiver_id="TALLTREE",
        group_id="1",
        quote_number=quote.quote_number,
        employer_name=quote.employer_name,
        plan_code=plan.plan_code,
        members=[{
            "employee_id": m.employee_id, "first_name": m.first_name, "last_name": m.last_name,
            "dob": m.dob, "ssn_last4": m.ssn_last4, "relationship": m.relationship
        } for m in members]
    )
    art = models.Artifact(quote_id=quote.id, kind="834", filename=f"{quote.quote_number}.834.txt", content=text.encode("utf-8"))
    db.add(art)

    quote.status = "SENT"
    db.commit()
    db.refresh(art)
    return {"artifact_id": art.id, "filename": art.filename, "status": quote.status}

@router.get("/{artifact_id}", dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def download(artifact_id: int, db: Session = Depends(get_db)):
    art = db.query(models.Artifact).filter(models.Artifact.id == artifact_id).first()
    if not art:
        raise HTTPException(status_code=404, detail="Not found")
    mime = "application/pdf" if art.kind == "pdf" else "text/plain"
    return Response(content=art.content, media_type=mime, headers={"Content-Disposition": f'attachment; filename="{art.filename}"'})
