from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db import models
from app.core.rbac import require_roles
from app.pricing.evaluator import evaluate_quote_pricing

router = APIRouter(prefix="/quotes", tags=["quotes"])

@router.get("/{quote_number}", dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def get_quote(quote_number: str, db: Session = Depends(get_db)):
    quote = db.query(models.Quote).filter(models.Quote.quote_number == quote_number).first()
    if not quote:
        raise HTTPException(status_code=404, detail="Not found")
    return {
        "quote_number": quote.quote_number,
        "market": quote.market,
        "employer_name": quote.employer_name,
        "status": quote.status,
        "dsl_text": quote.dsl_text,
    }

@router.post("/{quote_number}/pricing", dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def pricing(quote_number: str, plan_code: str, db: Session = Depends(get_db)):
    quote = db.query(models.Quote).filter(models.Quote.quote_number == quote_number).first()
    if not quote:
        raise HTTPException(status_code=404, detail="Not found")
    plan = db.query(models.Plan).filter(models.Plan.plan_code == plan_code).first()
    if not plan:
        raise HTTPException(status_code=400, detail="Unknown plan_code")
    summary = evaluate_quote_pricing(
        quote_number=quote.quote_number,
        market=quote.market,
        employer_name=quote.employer_name,
        plan_code=plan.plan_code,
        plan_name=plan.name,
        dsl_text=quote.dsl_text
    )
    return summary.model_dump()
