from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.rbac import require_roles
from app.db.session import get_db
from app.db import models

router = APIRouter(prefix="/ui", tags=["ui"])

class PlanOut(BaseModel):
    id: int
    plan_code: str
    name: str
    plan_type: str
    carrier: str

class QuoteRecentOut(BaseModel):
    quote_number: str
    employer_name: str
    market: str
    status: str
    created_at: str | None = None

class QuoteCreateIn(BaseModel):
    market: str
    employer_name: str
    dsl_text: str
    plan_code: str
    partner: str  # TallTree|VaultTPA

class QuoteCreateOut(BaseModel):
    quote_number: str

class ArtifactMetaOut(BaseModel):
    id: int
    kind: str
    filename: str
    content_type: str
    size_bytes: int
    created_at: str

class PartnerRuleOut(BaseModel):
    id: int
    partner: str
    rule_key: str
    rule_value: str
    notes: str

class PartnerRefOut(BaseModel):
    id: int
    partner: str
    ref_code: str
    scope: str
    source_field: str
    required: bool
    notes: str

class PartnerPlanMapOut(BaseModel):
    id: int
    partner: str
    internal_plan_code: str
    partner_plan_code: str
    line_of_business: str
    product_code: str
    active: bool
    notes: str

@router.get("/plans", response_model=list[PlanOut], dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def ui_plans(db: Session = Depends(get_db)):
    plans = db.query(models.Plan).filter(models.Plan.active == True).order_by(models.Plan.plan_code.asc()).all()  # noqa: E712
    return [PlanOut(id=p.id, plan_code=p.plan_code, name=p.name, plan_type=p.plan_type, carrier=p.carrier) for p in plans]

@router.get("/quotes/recent", response_model=list[QuoteRecentOut], dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def ui_recent_quotes(db: Session = Depends(get_db)):
    qs = db.query(models.Quote).order_by(models.Quote.created_at.desc()).limit(25).all()
    return [QuoteRecentOut(
        quote_number=q.quote_number,
        employer_name=q.employer_name,
        market=q.market,
        status=q.status,
        created_at=q.created_at.isoformat() if q.created_at else None,
    ) for q in qs]

@router.post("/quotes", response_model=QuoteCreateOut, dependencies=[Depends(require_roles("admin","underwriter","broker"))])
def ui_create_quote(payload: QuoteCreateIn, user=Depends(require_roles("admin","underwriter","broker")), db: Session = Depends(get_db)):
    plan = db.query(models.Plan).filter(models.Plan.plan_code == payload.plan_code, models.Plan.active == True).first()  # noqa: E712
    if not plan:
        raise HTTPException(status_code=400, detail="Unknown plan_code")

    u = db.query(models.User).filter(models.User.email == user["sub"]).first()
    if not u:
        raise HTTPException(status_code=401, detail="User not found")

    import uuid
    qn = f"Q{uuid.uuid4().hex[:10].upper()}"

    quote = models.Quote(
        quote_number=qn,
        market=payload.market,
        employer_name=payload.employer_name,
        status="DRAFT",
        dsl_text=payload.dsl_text,
        created_by_user_id=u.id
    )
    db.add(quote)
    db.commit()
    db.refresh(quote)

    sel = models.QuoteSelection(
        quote_id=quote.id,
        plan_id=plan.id,
        partner=payload.partner,
        tier="EE",
        employer_contrib=0,
        employee_contrib=0
    )
    db.add(sel)

    db.add_all([
        models.QuoteMember(quote_id=quote.id, employee_id="E1001", first_name="Alex", last_name="Rivera", dob="1988-03-11", ssn_last4="1234", relationship="EMP"),
        models.QuoteMember(quote_id=quote.id, employee_id="E1001", first_name="Jamie", last_name="Rivera", dob="1990-07-20", ssn_last4="5678", relationship="SPO"),
        models.QuoteMember(quote_id=quote.id, employee_id="E1001", first_name="Taylor", last_name="Rivera", dob="2016-01-05", ssn_last4="9012", relationship="CHD"),
    ])

    db.commit()
    return QuoteCreateOut(quote_number=quote.quote_number)

@router.get("/quotes/{quote_number}/artifacts", response_model=list[ArtifactMetaOut], dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def ui_quote_artifacts(quote_number: str, db: Session = Depends(get_db)):
    quote = db.query(models.Quote).filter(models.Quote.quote_number == quote_number).first()
    if not quote:
        raise HTTPException(status_code=404, detail="Quote not found")

    arts = db.query(models.Artifact).filter(models.Artifact.quote_id == quote.id).order_by(models.Artifact.created_at.desc()).all()
    out = []
    for a in arts:
        content_type = "application/pdf" if a.kind == "pdf" else "text/plain"
        out.append(ArtifactMetaOut(
            id=a.id,
            kind=a.kind,
            filename=a.filename,
            content_type=content_type,
            size_bytes=len(a.content or b""),
            created_at=a.created_at.isoformat() if a.created_at else ""
        ))
    return out

@router.get("/partners/{partner}/rules", response_model=list[PartnerRuleOut], dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def ui_partner_rules(partner: str, db: Session = Depends(get_db)):
    rows = db.query(models.Partner834Rule).filter(models.Partner834Rule.partner == partner).order_by(models.Partner834Rule.rule_key.asc()).all()
    return [PartnerRuleOut(id=r.id, partner=r.partner, rule_key=r.rule_key, rule_value=r.rule_value, notes=r.notes) for r in rows]

@router.get("/partners/{partner}/refs", response_model=list[PartnerRefOut], dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def ui_partner_refs(partner: str, db: Session = Depends(get_db)):
    rows = db.query(models.PartnerRefQualifier).filter(models.PartnerRefQualifier.partner == partner).order_by(models.PartnerRefQualifier.scope.asc(), models.PartnerRefQualifier.ref_code.asc()).all()
    return [PartnerRefOut(id=r.id, partner=r.partner, ref_code=r.ref_code, scope=r.scope, source_field=r.source_field, required=bool(r.required), notes=r.notes) for r in rows]

@router.get("/partners/{partner}/plan-maps", response_model=list[PartnerPlanMapOut], dependencies=[Depends(require_roles("admin","underwriter","broker","viewer"))])
def ui_partner_plan_maps(partner: str, db: Session = Depends(get_db)):
    rows = db.query(models.PartnerPlanCodeMap).filter(models.PartnerPlanCodeMap.partner == partner).order_by(models.PartnerPlanCodeMap.internal_plan_code.asc()).all()
    return [PartnerPlanMapOut(
        id=r.id, partner=r.partner,
        internal_plan_code=r.internal_plan_code,
        partner_plan_code=r.partner_plan_code,
        line_of_business=r.line_of_business,
        product_code=r.product_code,
        active=bool(r.active),
        notes=r.notes
    ) for r in rows]
