from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from io import BytesIO

def build_quote_pdf(*, title: str, summary: dict) -> bytes:
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    w, h = letter

    c.setFont("Helvetica-Bold", 18)
    c.drawString(72, h-72, "Connect Quote 360")
    c.setFont("Helvetica", 12)
    c.drawString(72, h-96, title)

    y = h-130
    c.setFont("Helvetica", 10)
    for k, v in summary.items():
        c.drawString(72, y, f"{k}: {v}")
        y -= 14
        if y < 72:
            c.showPage()
            y = h-72

    c.showPage()
    c.save()
    return buf.getvalue()
