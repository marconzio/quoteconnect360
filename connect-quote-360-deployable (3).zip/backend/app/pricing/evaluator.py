from .dsl import parse_dsl
from .canonical import PricingSummary, TierPremium

TIERS = ["EE","ES","EC","FAM"]

def evaluate_quote_pricing(*, quote_number: str, market: str, employer_name: str,
                           plan_code: str, plan_name: str, dsl_text: str) -> PricingSummary:
    d = parse_dsl(dsl_text)
    employer_pct = float(d.get("employer_pct", "0.0"))

    tier_premiums = []
    prem_total = emp_total = ee_total = 0.0

    for tier in TIERS:
        key = f"base_rate_{tier.lower()}"
        prem = float(d.get(key, "0"))
        employer = round(prem * employer_pct, 2)
        employee = round(prem - employer, 2)
        prem_total += prem
        emp_total += employer
        ee_total += employee
        tier_premiums.append(TierPremium(
            tier=tier, premium=round(prem,2),
            employer_contribution=employer, employee_contribution=employee
        ))

    return PricingSummary(
        quote_number=quote_number,
        market=market,
        employer_name=employer_name,
        plan_code=plan_code,
        plan_name=plan_name,
        tier_premiums=tier_premiums,
        totals={
            "premium_total": round(prem_total,2),
            "employer_total": round(emp_total,2),
            "employee_total": round(ee_total,2),
        },
        assumptions={k: str(v) for k, v in d.items()}
    )
