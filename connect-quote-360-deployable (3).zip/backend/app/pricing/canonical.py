from pydantic import BaseModel
from typing import Dict, List, Literal

Tier = Literal["EE","ES","EC","FAM"]

class TierPremium(BaseModel):
    tier: Tier
    premium: float
    employer_contribution: float
    employee_contribution: float

class PricingSummary(BaseModel):
    quote_number: str
    market: str
    employer_name: str
    plan_code: str
    plan_name: str
    tier_premiums: List[TierPremium]
    totals: Dict[str, float]
    assumptions: Dict[str, str]
