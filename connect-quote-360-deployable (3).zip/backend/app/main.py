from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from threading import Thread

from app.db.session import engine, SessionLocal, Base
from app.db.seed import seed

from app.api.auth import router as auth_router
from app.api.quotes import router as quotes_router
from app.api.artifacts import router as artifacts_router
from app.api.ui import router as ui_router
from app.api.sftp_watch import start_background_watcher

app = FastAPI(title="Connect Quote 360")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in (__import__("os").getenv("CORS_ORIGINS","*")).split(",")] if __import__("os").getenv("CORS_ORIGINS","*") != "*" else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(quotes_router)
app.include_router(artifacts_router)
app.include_router(ui_router)

@app.on_event("startup")
def on_startup():
    # Demo mode: create_all so it works without Alembic
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()

    t = Thread(target=start_background_watcher, args=(SessionLocal,), daemon=True)
    t.start()
