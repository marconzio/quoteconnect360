from sqlalchemy import String, Integer, DateTime, ForeignKey, Text, Boolean, Numeric, LargeBinary, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from datetime import datetime, timezone
from .session import Base

def utcnow():
    return datetime.now(timezone.utc)

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(50), default="viewer")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

class Plan(Base):
    __tablename__ = "plans"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    plan_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255))
    plan_type: Mapped[str] = mapped_column(String(10))
    carrier: Mapped[str] = mapped_column(String(255))
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Quote(Base):
    __tablename__ = "quotes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quote_number: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    market: Mapped[str] = mapped_column(String(20))
    employer_name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(30), default="DRAFT")
    dsl_text: Mapped[str] = mapped_column(Text)

    created_by_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_by: Mapped["User"] = relationship()

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    artifacts: Mapped[list["Artifact"]] = relationship(back_populates="quote", cascade="all, delete-orphan")

class QuoteMember(Base):
    __tablename__ = "quote_members"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quote_id: Mapped[int] = mapped_column(ForeignKey("quotes.id"), index=True)
    employee_id: Mapped[str] = mapped_column(String(64), index=True)
    first_name: Mapped[str] = mapped_column(String(100))
    last_name: Mapped[str] = mapped_column(String(100))
    dob: Mapped[str] = mapped_column(String(10))
    ssn_last4: Mapped[str] = mapped_column(String(4))
    relationship: Mapped[str] = mapped_column(String(10), default="EMP")

class QuoteSelection(Base):
    __tablename__ = "quote_selections"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quote_id: Mapped[int] = mapped_column(ForeignKey("quotes.id"), index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"))
    partner: Mapped[str] = mapped_column(String(50), default="TallTree", index=True)  # TallTree|VaultTPA
    tier: Mapped[str] = mapped_column(String(10))  # EE/ES/EC/FAM
    employer_contrib: Mapped[Numeric] = mapped_column(Numeric(10,2), default=0)
    employee_contrib: Mapped[Numeric] = mapped_column(Numeric(10,2), default=0)

class Artifact(Base):
    __tablename__ = "artifacts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quote_id: Mapped[int] = mapped_column(ForeignKey("quotes.id"), index=True)
    kind: Mapped[str] = mapped_column(String(50))  # pdf/834
    filename: Mapped[str] = mapped_column(String(255))

    # Simple v1: store bytes in DB for demo (works out of the box).
    # You can later swap to object storage with metadata fields.
    content: Mapped[bytes] = mapped_column(LargeBinary)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    quote: Mapped["Quote"] = relationship(back_populates="artifacts")

class Partner834Rule(Base):
    __tablename__ = "partner_834_rules"
    __table_args__ = (UniqueConstraint("partner","rule_key", name="uq_partner_rule_key"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    partner: Mapped[str] = mapped_column(String(50), index=True)
    rule_key: Mapped[str] = mapped_column(String(100))
    rule_value: Mapped[str] = mapped_column(String(255))
    notes: Mapped[str] = mapped_column(String(255), default="")

class PartnerRefQualifier(Base):
    __tablename__ = "partner_ref_qualifiers"
    __table_args__ = (UniqueConstraint("partner","ref_code","scope", name="uq_partner_ref_scope"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    partner: Mapped[str] = mapped_column(String(50), index=True)
    ref_code: Mapped[str] = mapped_column(String(10))
    scope: Mapped[str] = mapped_column(String(20))  # member|coverage|sponsor
    source_field: Mapped[str] = mapped_column(String(100))
    required: Mapped[bool] = mapped_column(Boolean, default=False)
    notes: Mapped[str] = mapped_column(String(255), default="")

class PartnerPlanCodeMap(Base):
    __tablename__ = "partner_plan_code_map"
    __table_args__ = (UniqueConstraint("partner","internal_plan_code", name="uq_partner_internal_plan"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    partner: Mapped[str] = mapped_column(String(50), index=True)
    internal_plan_code: Mapped[str] = mapped_column(String(50), index=True)
    partner_plan_code: Mapped[str] = mapped_column(String(50))
    line_of_business: Mapped[str] = mapped_column(String(10))
    product_code: Mapped[str] = mapped_column(String(50), default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    notes: Mapped[str] = mapped_column(String(255), default="")
