from sqlalchemy.orm import Session
from app.db.models import User, Plan, Partner834Rule, PartnerRefQualifier, PartnerPlanCodeMap
from app.core.security import hash_password

def seed(db: Session):
    # users
    if not db.query(User).filter(User.email == "admin@connect360.local").first():
        db.add(User(email="admin@connect360.local", password_hash=hash_password("admin123"), role="admin"))
        db.add(User(email="uw@connect360.local", password_hash=hash_password("uw123"), role="underwriter"))
        db.add(User(email="broker@connect360.local", password_hash=hash_password("broker123"), role="broker"))
        db.commit()

    # plans
    if not db.query(Plan).first():
        db.add_all([
            Plan(plan_code="C360MED01", name="Connect 360 Silver PPO", plan_type="SI", carrier="Carrier A"),
            Plan(plan_code="C360DEN01", name="Connect 360 Dental", plan_type="FI", carrier="Carrier B"),
            Plan(plan_code="C360VIS01", name="Connect 360 Vision", plan_type="FI", carrier="Carrier C"),
        ])
        db.commit()

    # partner mapping sample data (10 rows total)
    if not db.query(Partner834Rule).first():
        db.add_all([
            Partner834Rule(partner="TallTree", rule_key="isa_sender_qual", rule_value="ZZ", notes="Sender qualifier"),
            Partner834Rule(partner="TallTree", rule_key="require_n3_n4_dependents", rule_value="true", notes="Dependents require address"),
            Partner834Rule(partner="VaultTPA", rule_key="dtp_348_format", rule_value="RD8", notes="Vault expects coverage date range"),
            Partner834Rule(partner="VaultTPA", rule_key="require_n3_n4_dependents", rule_value="false", notes="Address not required for dependents at enrollment"),
        ])
        db.commit()

    if not db.query(PartnerRefQualifier).first():
        db.add_all([
            PartnerRefQualifier(partner="TallTree", ref_code="0F", scope="member", source_field="employee_id", required=True, notes="Subscriber/employee identifier"),
            PartnerRefQualifier(partner="VaultTPA", ref_code="0F", scope="member", source_field="employee_id", required=True, notes="Subscriber/employee identifier"),
            PartnerRefQualifier(partner="VaultTPA", ref_code="1L", scope="coverage", source_field="policy_number", required=False, notes="Optional policy/control number"),
        ])
        db.commit()

    if not db.query(PartnerPlanCodeMap).first():
        db.add_all([
            PartnerPlanCodeMap(partner="TallTree", internal_plan_code="C360MED01", partner_plan_code="TT_MED_SILVER_PPO", line_of_business="MED", product_code="TT-PROD-1001", active=True, notes="Internal silver PPO → TallTree code"),
            PartnerPlanCodeMap(partner="VaultTPA", internal_plan_code="C360MED01", partner_plan_code="VT_MED_SILVER_PPO", line_of_business="MED", product_code="VT-PROD-2001", active=True, notes="Internal silver PPO → Vault code"),
            PartnerPlanCodeMap(partner="TallTree", internal_plan_code="C360DEN01", partner_plan_code="TT_DEN_BASIC", line_of_business="DEN", product_code="TT-PROD-1101", active=True, notes="Dental mapping"),
        ])
        db.commit()
